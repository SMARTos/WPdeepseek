=== DeepSeek Content Generator ===
Contributors: smartosboy
Tags: ai, content, generator, deepseek
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Плагин для генерации контента с помощью DeepSeek API. Позволяет создавать черновики записей на основе ИИ.

== Installation ==
1. Загрузите папку плагина в директорию /wp-content/plugins/
2. Активируйте плагин через меню 'Плагины' в WordPress

== Changelog ==
= 1.0.0 =
* Первая версия плагина

== License ==
GPLv2 or later

== Author ==
admin@keytracker.ru 